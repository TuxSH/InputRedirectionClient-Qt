# InputRedirectionClient-Qt (TuxSh)
Input redirection client for the 3DS using QtGamepad

Supported platforms:

* Windows (via xinput, if you don't have a Xbox controller you should use x360ce)
* Linux (via evdev)
* OSX
* maybe others?

If you have multiple controllers connected at the same time, this software will combine their inputs.


Extended Edition 1.3 (gbrown5):

What this does:
-You can now load an image to fill the touchscreen window so you have a better idea of where to 
click rather than trying to guess using the blank window. See image

-Configure controller buttons.

-Right-click in touchscreen window to open a new image. 
The image should be 320x240 but the program will resize it if it isn't.

-Adjust transparency on Touchscreen window with a slider. 
(Code by: mastermune)

-Swap analog sticks on controller.

-Invert each sticks Y

-Allow scaled resizing of the touchpad window and overlay image.
